#include "Class.h"
Class::Class(const char layer_name, int class_num, Tutor* educator):layer_name(layer_name), class_num(class_num)
{                                //define constuctor
	this->student = nullptr;   
	this->amount_pupil = 0;
	this->educator = educator;

}
Class::Class(Class& copy)  //copy constructor
{
	layer_name = copy.layer_name;
	class_num = copy.class_num;
	amount_pupil = copy.amount_pupil;
	student = new Pupil *[amount_pupil];
	for (int i = 0; i < amount_pupil; i++)
	{
		student[i] = copy.student[i];
	}
	educator = copy.educator;
}
Class::~Class()  //Destroys
{
	delete educator;
	delete[]student;

	//delete student;

}
void Class::add_student(Pupil* student) //Add a student
{
	++amount_pupil;
	Pupil** temp = new Pupil * [amount_pupil];
	int i = 0;
	for (i; i < amount_pupil-1; i++) 
	{
		temp[i] = this->student[i];
	}
	temp[i] = student;

	delete[]this->student;
	this->student = new Pupil * [amount_pupil];
	this->student = temp;
	
}
Pupil* Class::num_student(int index) //Returning a student who is in a location index
{
	if (index >= 0 && index < amount_pupil)
	{
		for (int i = 0; i < amount_pupil; i++)
		{
			if (index == i)
			{
				return student[i];
			}
		}
	}
	else
	{
		cout << "Eror index" << endl;
		return 0;
	}
	return 0;
}
void Class::setlayer_name(char layer)
{
	this->layer_name = layer;
}

void  Class::seteducator(Tutor* T) 
{
	educator = T;
}