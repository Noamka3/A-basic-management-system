#include "Pupil.h"
//string name, string last_name, int id
Pupil::Pupil(string name, string last_name, int id, int* grade, int Grade_size, const char Class, int Num_Class)
:Person(name,last_name,id) // constructor.
{
	this->Grade_size = Grade_size;
	this->Grade = new int[Grade_size];
	for (int i = 0; i < Grade_size; i++)
	{
		Grade[i] = grade[i];

	}
	if ('a' <= Class && Class <= 'f')
	{
		this->Class = Class;
		if (1 <= Num_Class && Num_Class <= 3) 
		{
			this->Num_Class = Num_Class;
		}
		else
		{
			cout << "The class does not exist sorry" << endl;
			exit(1);
		}
	}
	else 
	{
		cout << "The layer does not exist,sorry" << endl;
		exit(1);
	}
}
Pupil::~Pupil()
{
	delete[]Grade;
}
Pupil::Pupil(const Pupil& copy):Person(copy) //copyconstructor
{
	this->Grade_size = copy.Grade_size;
	this->Grade = new int[this->Grade_size];
	for (int i = 0; i < Grade_size; i++) 
	{
		this->Grade[i] = copy.Grade[i];
	}
	//this->Grade = copy.Grade;
	this->Class = copy.Class;
	this->Num_Class = copy.Num_Class;
}

double Pupil::average()const//average.
{
	int sum = 0;
	for (int i = 0; i <Grade_size; i++) 
	{
		sum += Grade[i];
	}
	return sum / Grade_size;
}
bool Pupil::Excellent() //Checking if the student excels
{
	for (int i = 0; i < Grade_size; i++)
	{
		if (Grade[i] < 70) {
			return false;
		}
    }
	if (average() <= 85)
	{
		return false;
	}

	return true;
}
void Pupil::Print()const //Prints the father(Person) and then the Son.
{
	 Person::Print();
	cout << "Grade:";
	for (int i = 0; i < Grade_size; i++)
		cout << Grade[i] << " ";
	cout << endl;
	cout << "average:" << average() << endl;
	
}