#pragma once
#include "Layer.h"
#include "Worker.h"
#include "Manager.h"
#include "Secretary.h"
#include <typeinfo>


#define size_layer 6
class School
{
private:
	Layer** S_layer;
	int amount_layer;
	Person** P;
	int amount_school;
	bool manager;
	
public:
	School();
	~School();
	void Menu();
	void Addpupil();
	void AddTeacher();
	void Addtutor();
	void addManager();
	void addSecretary();
	void print_details()const;
	void print_outstanding()const;
	void print_Tutor()const;
	void Print_worker()const;
};

