#pragma once
#include "Pupil.h"
#include "Tutor.h"


class Class
{   //Tutor's company:) 
	friend class Tutor;
	
private: //protected.
	char layer_name;
	int class_num;
	Pupil** student;
	int amount_pupil;
	Tutor* educator;
public:
	Class(const char = 'a', int = 0, Tutor* = nullptr);
	Class(Class&);
	~Class();
	void add_student(Pupil*);
	Pupil* num_student(int);

	//get.set//
	Pupil** getStudent() { return student; };
	int getamount_pupli() { return amount_pupil; }
	char getlayer_name() { return layer_name; }
	int getclass_num() { return class_num; }
	void setlayer_name(char);
	void seteducator(Tutor*);
	void setclass_num(int class_num) { this->class_num = class_num; }
	Tutor* geteducator() { return educator; }
	
	
};

