#pragma once
#include "Teacher.h"
#include "Class.h"

class Tutor : public Teacher
{
	friend class Class;
private: 
	
	Class* C;
public:

	Tutor(string, string, int, int, string*, int); 
	Tutor(Tutor&);
	~Tutor() { /*delete[]C;*/ } //Destroys 
	double Return_salary()const; //Tutor salary
	bool Excellent();
	void print_Student()const;
	void Print()const;
	void set_C(Class*);
	Class* get_C() { return C; }
};

