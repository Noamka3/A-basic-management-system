#include "Secretary.h"
void Secretary::Print()const
{
	cout << "Secretary:" << endl;
	Worker::Print();
	cout << "Secretary Salary:" << Return_salary() << endl;
	cout << "Number of children attending school:" << children_school << endl<<endl;

}
