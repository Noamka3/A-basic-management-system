#include "Person.h"
Person::Person(string name, string last_name, int ID) :name(name), last_name(last_name), ID(ID) {}//constructor
void Person::Print()const//print Person
{
	//about the Person*
	cout << "*Details:" << endl;
	cout << "Name:" << name << endl;
	cout << "Last Name:" << last_name << endl;
	cout << "ID:" << ID << endl;
}
Person::Person(const Person& copy)
{
	name = copy.name;
	last_name = copy.last_name;
	ID = copy.ID;
}