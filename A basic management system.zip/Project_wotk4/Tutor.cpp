#include "Tutor.h"

Tutor::Tutor(string name, string last_name, int id, int seniority, string* Profession, int amount ):Teacher(name,last_name,id,seniority,Profession,amount),C(nullptr){}

Tutor::Tutor(Tutor& copy) : Teacher(copy)
{
	this->C = copy.C;  //copy constructor
}
double Tutor::Return_salary()const
{
	return Teacher::Return_salary() + 1200; //salary + 1200
}
bool Tutor::Excellent()
{
	int count = 0;
	for (int i = 0; i < C->getamount_pupli(); i++) //Checks the percentage of outstanding students in the class.
	{
		if (C->getStudent()[i]->Excellent() == true)
			count++;
	}

	return count / C->getamount_pupli() * 100 > 60;
}
void Tutor::print_Student()const
{
	for (int i = 0; i < C->getamount_pupli(); i++) //
	{
		C->getStudent()[i]->Print();  //Printing outstanding students
		if (C->getStudent()[i]->Excellent() == true)
		{
			cout << "*excellent student !*" << endl;
		}
	}
}
void Tutor::Print()const //print tutor 
{
	cout << "Tutor:" << endl;
	Teacher::Print();
	cout << "teaches the class:[" << C->getlayer_name() << "] and in class [" << C->getclass_num() << "]." << endl;
	cout << "Students students in class:" << endl << endl;
	


}
void  Tutor::set_C(Class* C1)
{
	this->C = C1;
}