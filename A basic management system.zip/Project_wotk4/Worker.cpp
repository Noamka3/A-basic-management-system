#include "Worker.h"
Worker::Worker(const Worker& copy):Person(copy)
{
	seniority = copy.seniority;
}
void Worker::Print()const 
{
	Person::Print();
	//cout << "Salary:" << Return_salary() << endl;
	cout << "years of seniority:" << seniority << endl;
}