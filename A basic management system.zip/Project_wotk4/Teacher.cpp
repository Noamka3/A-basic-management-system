#include "Teacher.h"
Teacher::Teacher(string name,string last_name,int id , int seniority,string* Profession, int amount) : Worker(name,last_name,id,seniority) ,amount_Profession(amount)
{
	this->Profession = new string[amount];
	
	for (int i = 0; i < amount_Profession; i++)
	{
		this->Profession[i] = Profession[i];
	}
}
Teacher::Teacher(const Teacher& copy) :Worker(copy)
{
	amount_Profession = copy.amount_Profession;
	Profession = new string[amount_Profession];
	for (int i = 0; i < amount_Profession; i++)
	{
		Profession[i] = copy.Profession[i];
	}
}

double Teacher::Return_salary() const
{
	return Basis * (amount_Profession + 1 / 10) + 200 * get_seniority();
}
bool Teacher::Excellent()
{
	return amount_Profession > 5;
}
void Teacher::print_Profession()const
{
	cout << "the subjects the teacher teaches: ";
	for (int i = 0; i < amount_Profession; i++)
	{
		cout <<"[" << Profession[i] << "]";
		if (i < amount_Profession - 1)
		{
			cout << ",";
		}
	}
	cout << endl;
}
void Teacher::Print() const 
{
	// cout << "Teacher:" << endl;
	//Worker::Person::Print_Person();
	Worker::Print();
	print_Profession();
	cout << "Salary:" << Return_salary() << endl;

}