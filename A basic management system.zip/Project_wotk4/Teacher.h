#pragma once
#include "Worker.h"


class Teacher:public Worker
{
private:
	string* Profession;
	int amount_Profession;
public:
	Teacher(string,string,int,int, string* = nullptr, int = 0);
	Teacher(const Teacher&);
    ~Teacher() { delete[]Profession; }
	virtual double Return_salary()const;
	virtual bool Excellent();
	void print_Profession()const;
	virtual void Print()const;
	
};

