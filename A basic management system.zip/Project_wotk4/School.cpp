#include "School.h"

School::School(): amount_layer(size_layer),manager(false), amount_school(0)
{
	char letter = 'a';
	S_layer = new Layer*[amount_layer];
	for (int i = 0; i < amount_layer; i++,letter++)
	{
		S_layer[i] = new Layer (letter);
		
	}
	this->P = new Person*[amount_school];
}
void School::Menu()
{
	int X = 0;
	while (X != 1)
	{


		int temp;
		cout << "\x1B[33mMenu\033[0m:" << endl;
		cout << "\x1B[31m1\033[0m" << "- Add Pupil " << endl;
		cout << "\x1B[31m2\033[0m" << "- Add Teacher" << endl;
		cout << "\x1B[31m3\033[0m" << "- Add tutor" << endl;
		cout << "\x1B[31m4\033[0m" << "- Add Mangaer" << endl;
		cout << "\x1B[31m5\033[0m" << "- Add Secretary" << endl;
		cout << "\x1B[31m6\033[0m" << "- print_details" << endl;
		cout << "\x1B[31m7\033[0m" << "- print_outstanding" << endl;
		cout << "\x1B[31m8\033[0m" << "- print Tutor" << endl;
		cout << "\x1B[31m9\033[0m" << "- Print worker" << endl;
		cout << "\x1B[31m10\033[0m"<< "- Exit" << endl;
		cin >> temp;

		switch (temp)
		{
		case 1:
			cout << "\x1B[33m*add Pupil*\033[0m" << endl;
			Addpupil();
			break;
		case 2:
			cout << "\x1B[33m*Add Teacher*\033[0m" << endl;
			AddTeacher();
			break;
		case 3:

			cout << "\x1B[33m*Add tutor*\033[0m" << endl;
			Addtutor();
			break;
		case 4:
			cout << "\x1B[33m*Add Manager*\033[0m" << endl;
			addManager();
			break; 
		case 5:
			cout << "\x1B[33m*Add Secretary*\033[0m" << endl;
			addSecretary();
			break;
		case 6:
			cout << "\x1B[33m*Print Details*\033[0m" << endl;
			print_details();
			
			break;
		case 7:
			cout << "\x1B[33m*Print outstanding*\033[0m" << endl;
			print_outstanding();
				break;
		case 8:
			cout << "\x1B[38m*Print Tutor*\033[0m" << endl;
			print_Tutor();
				break;
		case 9:
			cout << "\x1B[33m*Print Worker*\033[0m" << endl;
			Print_worker();
				break;
		case 10:
			
			cout << "Exit";
			X = 1;
			break;
		default:
			cout << "Invalid Please try again!" << endl;
			break;
		}
	}

}
School::~School()
{
	if (S_layer) 
	{
		for (int i = 0; i < amount_layer; i++)
			delete S_layer[i];
		delete[]S_layer;
	}
	if (P)
	{
		for (int i = 0; i < amount_school; i++)
			delete P[i];
		delete[]P;
	}
}
void School::Addpupil()
{
	string name, last_name;
	int id, grade_size, Num_Class;
	int* grade;
	char Class;
	char classs[] = { 'a','b','c','d','e','f' };
	int Bool = 1;
	cout << "name:";
	cin >> name;
	cout << "Last name:";
	cin >> last_name;
	cout << "Student ID:";
	cin >> id;
	cout << "Which layer the student studies(a-f)?:";
	cin >> Class;
	cout << "Class number(1-3):";
	cin >> Num_Class;
	cout << "How many grades does the student have:";
	cin >> grade_size;
	grade = new int[grade_size];
	cout << "Type in the scores:";
	for (int i = 0; i < grade_size; i++)
		cin >> grade[i];
	cout << endl;
	Pupil* student = new Pupil(name, last_name, id, grade, grade_size, Class, Num_Class);
	for(int i =0; i < amount_layer;i++)
		if(classs[i] == Class)
	     S_layer[i]->get_C()[Num_Class-1]->add_student(student);
	for (int i = 0; i < amount_school; i++)
	{
		if (this->P[i]->get_ID() == id)
		{
			cout << "The student is already in the school system." << endl;
			Bool = 0;
		}
	}
	if (Bool)
	{
		int i = 0;
		amount_school += 1;
		Person** temp = new Person*[amount_school];
		for (i; i < amount_school-1; i++)
		{
			temp[i] = this->P[i];
		}
		temp[i] = student;

		delete[]P;
		P = new Person * [amount_school];
		P = temp;
		cout << "Pupli added." << endl;
	}

}
void School::AddTeacher()
{
	string name, last_name;
	string* Profession;
	int id, amount;
	int seniority;
	int Bool = 1;

	cout << "name:";
	cin >> name;
	cout << "Last name:";
	cin >> last_name;
	cout << "Teacher ID:";
	cin >> id;
	cout << "Seniority of the school teacher:";
	cin >> seniority;
	cout << "How many subjects does the teacher teach?:";
	cin >> amount;
	Profession = new string[amount];
	cout << "What subjects do you teach?:";
	for (int i = 0; i < amount; i++)
		cin >> Profession[i];
	Teacher* teacher = new Teacher(name, last_name, id, seniority, Profession, amount);
	for (int i = 0; i < amount_school; i++)
	{
		if (this->P[i]->get_ID() == id)
		{
			cout << "The teacher is already in the system" << endl;
			Bool = 0;
		}
	}
	if (Bool)
	{
		int i = 0;
		amount_school += 1;
		Person** temp = new Person * [amount_school];
		for (i; i < amount_school - 1; i++)
		{
			temp[i] = this->P[i];
		}
		temp[i] = teacher;

		delete[]P;
		P = new Person * [amount_school];
		P = temp;
		cout << "Teacher added." << endl;
	}
	cout << endl;
}
void School::Addtutor() 
{
	string name, last_name;
	string* Profession;
	int id, amount,Num_Class;
	int seniority;
	int Bool = 1;
	char Class1;
	char classs[] = { 'a','b','c','d','e','f' };

	cout << "name:";
	cin >> name;
	cout << "Last name:";
	cin >> last_name;
	cout << "Tutor ID:";
	cin >> id;
	cout << "Seniority of the school tutor:";
	cin >> seniority;
	cout << "How many subjects does the teacher teach?:";
	cin >> amount;
	Profession = new string[amount];
	cout << "What subjects does he teach?:";
	for (int i = 0; i < amount; i++)
		cin >> Profession[i];
	Tutor* tutor = new Tutor(name, last_name, id, seniority, Profession, amount);
	cout << "What grade does the educator teach(a-f)?:";
	cin >> Class1;
	cout << "Class number(1-3):";
	cin >> Num_Class;
	for (int i = 0; i < amount_layer; i++)
		if (classs[i] == Class1)
		{
			tutor->set_C(this->S_layer[i]->return_Class(Num_Class));
			this->S_layer[i]->return_Class(Num_Class-1)->seteducator(tutor);
			
		}
	for (int i = 0; i < amount_school; i++)
	{
		if (this->P[i]->get_ID() == id)
		{
			cout << "The educator is already in the school system." << endl;
			Bool = 0;
		}
	}
	if (Bool)
	{
		int i = 0;
		amount_school += 1;
		Person** temp = new Person * [amount_school];
		for (i; i < amount_school - 1; i++)
		{
			temp[i] = this->P[i];
		}
		temp[i] = tutor;

		delete[]P;
		P = new Person * [amount_school];
		P = temp;
		cout << "Tutor added." << endl;
	}


	
	
	//string name, string last_name, int id, 
	//	int seniority, string* Profession, int amount, Class* C

}
void School::addManager()
{
	if (manager == false)
	{


		string name, last_name;
		int id;
		int seniority;
		int Bool = 1;

		cout << "name:";
		cin >> name;
		cout << "Last name:";
		cin >> last_name;
		cout << "Manager ID:";
		cin >> id;
		cout << "Seniority of a school Manager:";
		cin >> seniority;
		Manager* M = new Manager(name, last_name, id, seniority);

		for (int i = 0; i < amount_school; i++)
		{
			if (this->P[i]->get_ID() == id)
			{
				cout << "The educator is already in the school system." << endl;
				Bool = 0;
			}
		}
		if (Bool)
		{
			int i = 0;
			amount_school += 1;
			Person** temp = new Person * [amount_school];
			for (i; i < amount_school - 1; i++)
			{
				temp[i] = this->P[i];
			}
			temp[i] = M;

			delete[]P;
			P = new Person * [amount_school];
			P = temp;
			cout << "Manager added." << endl;
			manager = true;
		}

	}
	else 
	{
		cout << "There is already a school Manager!." << endl;
	}

}
void School::addSecretary() 
{
	string name, last_name;
	int seniority, children,id;
	int Bool = 1;

	cout << "name:";
	cin >> name;
	cout << "Last name:";
	cin >> last_name;
	cout << "Secretary ID:";
	cin >> id;
	cout << "Seniority of a school Secretary:";
	cin >> seniority;
	cout << "The number of children attending her school:";
	cin >> children;
	cout << "The children of the secretary who study:" << endl;
	Secretary* S = new Secretary(name, last_name, id, seniority, children);
	for (int i = 0; i < children; i++) 
	{
		Addpupil();
	}

	int i = 0;
	amount_school += 1;
	Person** temp = new Person * [amount_school];
	for (i; i < amount_school - 1; i++)
	{
		temp[i] = this->P[i];
	}
	temp[i] = S;

	delete[]P;
	P = new Person * [amount_school];
	P = temp;
	cout << "Secretary added." << endl;
	manager = true;


}
void School::print_details()const
{
	for (int i = 0; i < amount_school; i++) 
	{
		P[i]->Print();
		cout << endl;
	}
}
void School::print_outstanding()const
{
	for (int i = 0; i < amount_school; i++)
	{
		if (P[i]->Excellent() == true) 
		{
			P[i]->Print();
		}
	}
}
void School::print_Tutor()const
{
	int id;
	cout << "please Enter id of Tutor:" << endl;
	cin >> id;
   for(int i =0; i<amount_school; i++) 
   {
	   if(P[i]->get_ID() == id)
       {
		   if (typeid(*this->P[i]) == typeid(Tutor)) //test typeid
		   {
			   Tutor* temp = dynamic_cast<Tutor*>(P[i]);
			   if (temp)
			   {
				   temp->Print();
				   temp->print_Student();
			   }
	       }
       }
   }
}

void School::Print_worker()const
{
	double min = 0;
	int index;
	
	for (int i = 0; i < amount_school; i++)
	{
		Worker* temp = dynamic_cast<Worker*>(P[i]);
		if (temp)
		{
			min += temp->Return_salary();
		}
	}
	if (min != 0)
	{
		cout << "Minimum salary of the employee:" << endl;

		for (int i = 0; i < amount_school; i++)
		{
			Worker* temp = dynamic_cast<Worker*>(P[i]);
			if (temp->Return_salary() <= min)
			{
				min = temp->Return_salary();
				index = i;
			}

		}

		P[index]->Print();
	}
	else
	{
		cout<<"There are no salaries for anyone." << endl;
	}

}

