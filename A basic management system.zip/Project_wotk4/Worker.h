#pragma once
#include "Person.h"
#define Basis 4500
class Worker:public Person
{
private:
	int seniority;
public:
	//string name, string last_name, int id
	Worker(string name , string last_name, int id, int seniority = 0) :Person(name,last_name,id), seniority(seniority){}
	Worker(const Worker&);
	virtual ~Worker() {};
	virtual double Return_salary()const = 0 {};
	virtual bool Excellent() = 0 {};
   virtual void Print()const;
	int get_seniority() const { return seniority;}
};

