#pragma once
#include<iostream>
#include <string>
using namespace std;

class Person
{
protected:
	string name;
	string last_name;
	int ID;
public:
	Person(string = "Null", string = "Null", int = 0);//constructor
	Person(const Person&);
	virtual ~Person() {};//Destroys
	virtual void Print()const;
	virtual bool Excellent() = 0 {}; // ����� ���

	//Get
	string getName()const  { return name; }
	string getLast_Name()const { return last_name; }
	virtual int get_ID() const { return ID; }



};

