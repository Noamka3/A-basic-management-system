#pragma once
#include "Person.h"
class Pupil :public Person
{
private:
	int* Grade;
	int Grade_size;
	char Class;
	int Num_Class;

public:
	//string,string,int
	Pupil(string, string, int, int* = nullptr , int = 0, const char ='a', int = 1); //constructor
    ~Pupil(); //Destructor
	Pupil(const Pupil&);
	double average()const;
     bool Excellent();
	void Print()const;

	//get 
	int* getGrade() { return Grade; }
	
};
