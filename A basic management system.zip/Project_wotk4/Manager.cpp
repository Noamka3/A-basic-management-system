#include "Manager.h"
void Manager::Print()const 
{
	cout << "Manager:" << endl;
	Worker::Print();
	cout << "Manager Salary:" << Return_salary() << endl<<endl;
}
