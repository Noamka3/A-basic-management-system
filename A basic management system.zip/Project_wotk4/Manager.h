#pragma once
#include "Tutor.h"
class Manager : public Worker
{
public:
	Manager(string name, string last_name, int id, int seniority) :Worker(name, last_name, id, seniority) {};
	~Manager() {};
	double Return_salary()const{ return (Basis*3)+(Worker::get_seniority()*500);} //salary
	bool Excellent() { return Worker::get_seniority() > 4;}; //excellent Manager
	void Print()const;
};

