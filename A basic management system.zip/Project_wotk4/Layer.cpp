#include "Layer.h"
Layer::Layer(const char layer):layer(layer),amount_C(3)
{
	C = new Class*[3];
	for (int i = 0; i < amount_C; i++) 
	{
		C[i] = new Class(layer, i+1);
	}
	

}
Class* Layer::return_Class(int index) 
{
	if (index > 0 && index <= 3)
	{
		return C[index - 1];
	}
	
}
/*
void Layer::setTutor(Tutor& tutor)
{

}*/
