#include"Pupil.h"
#include "Manager.h"
#include "Secretary.h"
#include "School.h"
#define Max 5

int main() 
{
	School school;
	school.Menu();

	return 0;
}