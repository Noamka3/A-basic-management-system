#pragma once
#include "Worker.h"
class Secretary :public Worker
{
private:
	unsigned int children_school; //The number of children the secretary.
public:
	Secretary(string name , string Last_name, int  id, int seniority ,int childern = 0): Worker(name,Last_name,id,seniority), children_school(childern) {};
	//Secretary(Secretary&);
	~Secretary() {};
	double Return_salary()const { return Basis +(children_school * 250); } //salary
	virtual bool Excellent() { return Worker::get_seniority() > 15;} //excellent secretary
	void Print()const;




};

