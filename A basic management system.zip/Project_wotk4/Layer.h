#pragma once
#include "Class.h"

class Layer
{
private:
	char layer;
	Class** C;
	int amount_C;
public:
	Layer(const char);
	~Layer() { delete[]C;}
	Class* return_Class(int);

	Class** get_C() { return C;}
	//void setTutor(Tutor&);

};

